package TP2_EJ2 - Nahuel Ripoll;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        int opc = 0;
        int ingresarStock = 0;
        boolean continuar = false;
        Scanner sc = new Scanner(System.in);
        ArrayList<Productos> listaProductos = new ArrayList<Productos>();
        do {
            System.out.print("1: REGISTRAR PRODUCTOS   2: VER PRODUCTOS 3: SALIR");
            opc = sc.nextInt();
            switch (opc) {
                case 1:
                     Productos producto = new Productos();
                    sc.nextLine();
                    System.out.print("Nombre del producto : ");
                     producto.setNombre(sc.nextLine());
                    System.out.print("Codigo del producto: ");
                     producto.setCodigo(sc.nextLine());
                    do {
                        Scanner scBucle2 = new Scanner(System.in);
                        System.out.print("Stock : ");
                        try {
                            ingresarStock = scBucle2.nextInt();
                            producto.setStock(ingresarStock);
                            listaProductos.add(producto);
                            continuar = true;
                        } catch (InputMismatchException ignored) {
                            System.out.println("Por favor, ingrese un numero.");
                        }
                    }while(!continuar);
                    break;
                case 2:
                    for (Productos productos2 : listaProductos) {
                        if (productos2.getStock() < 10) {
                            System.out.println("Nombre del producto: " + productos2.getNombre() + "  Codigo del producto: " + productos2.getCodigo() + "  Stock: " + productos2.getStock());

                        }
                    }
                    break;
            }
        }while(opcion != 3 );
    }
}