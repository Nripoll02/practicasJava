package TP2_EJ1 - Nahuel Ripoll;

public class Empleado extends Persona{
    private int numDespacho;

    public Empleado(){}

    public int getNumDespacho() {
        return numDespacho;
    }
    public void setNumDespacho(int numDespacho) {
        this.numDespacho = numDespacho;
    }
}