package TP2_EJ1 - Nahuel Ripoll;


public class Alumno extends Persona{

    public Alumno(){}
}