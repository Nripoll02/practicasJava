package TP2_EJ1 - Nahuel Ripoll;
public class Profesor extends Persona{
    private int numOficina;

    public Profesor(){}

    public int getNumOficina() {
        return numOficina;
    }
    public void setNumOficina(int numOficina) {
        this.numOficina = numOficina;
    }
}
