package TP2_EJ1 - Nahuel Ripoll;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args){
        int opc = 0;
        Scanner sc = new Scanner(System.in);
        ArrayList <Persona> listaPersona = new ArrayList<>();
        Alumno alumno = new Alumno();
        Profesor profesor = new Profesor();
        Empleado empleado = new Empleado();

        do {
            try{
                System.out.print(" 1: INRESAR ALUMNO\n 2: INGRESAR PROFE\n 3: INGRESAR EMPLEADO\n 4: MOSTRAR LISTA\n 5: SIGUIENTE\n 6: ELIMINAR\n 7: SALIR");
                opcion = sc.nextInt();

                switch (opc) {
                    case 1:
                        alumno.setTipo(1);
                        sc.nextLine();
                        System.out.print("Nombre : ");
                        alumno.setNombre(sc.nextLine());
                        System.out.print("Apellido : ");
                        alumno.setApellido(sc.nextLine());
                        System.out.print("DNI : ");
                        alumno.setDni(sc.nextLine());
                        System.out.print("Estado civil : ");
                        alumno.setEstadoCivil(sc.nextLine());
                        System.out.print("Año incorporacion : ");
                        alumno.setAgeIncorporacion(sc.nextInt());
                        listaPersona.add(alumno);
                        break;
                    case 2:
                        profesor.setTipo(2);
                        sc.nextLine();
                        System.out.print("Nombre : ");
                        profe.setNombre(sc.nextLine());
                        System.out.print("Apellido : ");
                        profe.setApellido(sc.nextLine());
                        System.out.print("DNI : ");
                        profe.setDni(sc.nextLine());
                        System.out.print("Estado civil : ");
                        profe.setEstadoCivil(sc.nextLine());
                        System.out.print("Año incorporacion : ");
                        profe.setAgeIncorporacion(sc.nextInt());
                        System.out.print("Oficina : ");
                        profe.setNumOficina(sc.nextInt());
                        listaPersona.add(profesor);
                        break;
                    case 3:
                        empleado.setTipo(3);
                        sc.nextLine();
                        System.out.print("Nombre : ");
                        empleado.setNombre(sc.nextLine());
                        System.out.print("Apellido : ");
                        empleado.setApellido(sc.nextLine());
                        System.out.print("DNI : ");
                        empleado.setDni(sc.nextLine());
                        System.out.print("Estado civil : ");
                        empleado.setEstadoCivil(sc.nextLine());
                        System.out.print("Año incorporacion : ");
                        empleado.setAgeIncorporacion(sc.nextInt());
                        System.out.print("Despacho : ");
                        empleado.setNumDespacho(sc.nextInt());
                        listaPersona.add(empleado);
                        break;
                    case 4:
                        for (Persona persona : listaPersona) {
                            System.out.println("Nombre: " + persona.getNombre() + "   Apellido: " + persona.apellido + "   DNI: " + persona.getDni() + "   Estado Civil: " + persona.getEstadoCivil() + "   Año incorporacion: " + persona.getAgeIncorporacion());
                        }
                        break;
                    case 5:
                        for (Persona persona : listaPersona) {
                            do {
                                System.out.print("1: Siguiente  2 : cancelar opcion :  ");
                                opcion = sc.nextInt();
                                System.out.println("Nombre: " + persona.getNombre() + "   Apellido: " + persona.apellido + "   DNI: " + persona.getDni() + "   Estado Civil: " + persona.getEstadoCivil() + "   Año incorporacion: " + persona.getAgeIncorporacion());
                                break;
                            } while (opcion != 2);
                        }
                        break;
                    case 6:
                        for (int i = 0; i < listaPersona.size(); i++) {
                            listaPersona.get(i).getTipo();
                            System.out.print("Eliminar -->  1: Alumno   2: Profesor   3: Empleado   opcion : ");
                            opcion = sc.nextInt();
                            switch (opc) {
                                case 1:
                                    if (listaPersona.get(i).getTipo() == 1) ;
                                    listaPersona.remove(i);
                                    break;
                                case 2:
                                    if (listaPersona.get(i).getTipo() == 2) ;
                                    listaPersona.remove(i);
                                    break;
                                case 3:
                                    if (listaPersona.get(i).getTipo() == 3) ;
                                    listaPersona.remove(i);
                                    break;
                            }
                        }
                        break;
                    case 7 :break;
                    default:
                        System.out.println("Elija numero del 1 al 6");
                }
            }
            catch(InputMismatchException e){
                System.out.println ("El numero es incorrecto");
                break;
            }
        }while (opc != 7 );
    }
}

