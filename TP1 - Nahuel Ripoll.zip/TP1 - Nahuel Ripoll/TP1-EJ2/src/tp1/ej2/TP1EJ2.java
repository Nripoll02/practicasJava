
package tp1.ej2;


public class TP1EJ2 {

  
    public static void main(String[] args) {
       Auto miAuto;
        miAuto = new Auto();
        
        
        miAuto.Combustible();
        
        
        miAuto.Kilometros();
     
       
        miAuto.Result(0, 0);
        
       
        miAuto.Comp();
    }
}
       


        
   