
package tp1_ej4;


public class TP1_EJ4 {

    public static void main (String[] args){
           Cuenta miCuenta = new Cuenta();
           Persona miPersona = new Persona();
           
           miCuenta.setSaldo_Disponible(1200);
           miCuenta.setDni(38174933);
           miPersona.setCuentaBancaria(135218);
           
           
           
        
    }
    
}
   
