
package tp1.ej3;



public class TP1EJ3 {

    
    public static void main(String[] args) {
       Rectangulo rectangulos = new Rectangulo();

           rectangulos.datos();
           rectangulos.datoTriangulo1();
           rectangulos.datoTriangulo2();
           rectangulos.comparacion();

    }
}
        
    
    

